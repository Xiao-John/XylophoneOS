#!/usr/bin/env python3
"""Task-local build bootstrap; never rewrites repository toolchain locks."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

root = Path(__file__).resolve().parent
sources = root / 'sources'
build = root / 'build'
prefix = root / 'prefix'
logs = root / 'logs'
for directory in (sources, build, prefix, logs):
    directory.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment['PATH'] = str(prefix / 'bin') + ':' + environment['PATH']
commands = []

def extract(name):
    target = sources / name
    if target.exists():
        return target
    archive = root / 'downloads' / (name + '.tar.xz')
    with tarfile.open(archive) as tar:
        tar.extractall(sources, filter='data')
    return target

def run(label, command, cwd):
    record = {'label': label, 'command': [str(x) for x in command],
              'cwd': str(cwd), 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    commands.append(record)
    print('START', label, flush=True)
    with (logs / (label + '.log')).open('w') as log:
        result = subprocess.run(record['command'], cwd=cwd, env=environment,
                                stdout=log, stderr=subprocess.STDOUT)
    record['returncode'] = result.returncode
    record['ended_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    (logs / 'bootstrap-tools.json').write_text(json.dumps(commands, indent=2) + '\n')
    print('DONE', label, result.returncode, flush=True)
    if result.returncode:
        print((logs / (label + '.log')).read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)

nasm = extract('nasm-3.02')
run('nasm-configure', [nasm / 'configure', '--prefix=' + str(prefix)], nasm)
run('nasm-build', ['make', '-j4'], nasm)
run('nasm-install', ['make', 'install'], nasm)
binutils = extract('binutils-2.47')
b = build / 'binutils'
b.mkdir(exist_ok=True)
run('binutils-configure', [binutils / 'configure', '--target=x86_64-elf',
    '--prefix=' + str(prefix), '--with-sysroot', '--disable-nls',
    '--disable-werror', '--disable-multilib'], b)
run('binutils-build', ['make', '-j4'], b)
run('binutils-install', ['make', 'install'], b)
gcc = extract('gcc-16.2.0')
b = build / 'gcc'
b.mkdir(exist_ok=True)
run('gcc-configure', [gcc / 'configure', '--target=x86_64-elf', '--prefix=' + str(prefix),
    '--disable-nls', '--enable-languages=c,c++', '--without-headers', '--disable-multilib',
    '--disable-shared', '--disable-bootstrap', '--disable-libssp', '--disable-libquadmath',
    '--disable-libgomp', '--disable-libatomic'], b)
run('gcc-build', ['make', '-j4', 'all-gcc', 'all-target-libgcc'], b)
run('gcc-install', ['make', 'install-gcc', 'install-target-libgcc'], b)
versions = {}
for name in ('nasm', 'x86_64-elf-gcc', 'x86_64-elf-g++', 'x86_64-elf-ld'):
    path = prefix / 'bin' / name
    versions[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                      'version': subprocess.check_output([str(path), '--version'], text=True).splitlines()[0]}
(logs / 'tools-built.json').write_text(json.dumps(versions, indent=2) + '\n')
print(json.dumps(versions, indent=2), flush=True)
