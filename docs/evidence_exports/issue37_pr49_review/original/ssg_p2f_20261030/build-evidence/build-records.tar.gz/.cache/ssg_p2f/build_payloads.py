#!/usr/bin/env python3
"""Build ordinary and test-only Oracle Browser payloads from the same source."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

cache = Path(__file__).resolve().parent
root = cache.parents[1]
out = root / 'build/ssg_p2f'
env = os.environ.copy()
env['PATH'] = str(cache / 'prefix/bin') + ':' + env['PATH']
env['NASM'] = str(cache / 'prefix/bin/nasm')
env['QEMU'] = str(cache / 'qemu-prefix/bin/qemu-system-x86_64')
common = ['--sdk', out / 'sdk', '--qt-build', out / 'qt-widgets',
          '--qt-source', cache / 'qt-target-source', '--host-qt', cache / 'host-qt-official',
          '--binutils', cache / 'target-tools']
receipt = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
           'commands': [], 'status': 'BUILDING'}
for label, command in (
    ('payloads', [sys.executable, root / 'scripts/build_ssg_p1.py', *common, '--output', out / 'payloads']),
    ('oracle-browser', [sys.executable, root / 'src/ports/aurora_browser/build.py', *common,
                        '--test-structure-oracle', '--output', out / 'oracle-browser/browser.elf']),
):
    row = {'label': label, 'command': [str(x) for x in command],
           'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    receipt['commands'].append(row)
    print('START', label, flush=True)
    with (cache / 'logs' / (label + '-build.log')).open('w') as log:
        result = subprocess.run(row['command'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row['returncode'] = result.returncode
    row['ended_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    if result.returncode:
        receipt['status'] = 'FAILED'
    (cache / 'logs/payloads-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('DONE', label, result.returncode, flush=True)
    if result.returncode:
        print((cache / 'logs' / (label + '-build.log')).read_text()[-6000:], flush=True)
        raise SystemExit(result.returncode)
receipt['status'] = 'BUILT'
receipt['artifacts'] = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in [out / 'payloads/session.elf', out / 'payloads/consumer/ssg-consumer.elf',
                 out / 'payloads/notes/notes.elf', out / 'payloads/browser/browser.elf',
                 out / 'oracle-browser/browser.elf']}
(cache / 'logs/payloads-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt['artifacts'], indent=2), flush=True)
