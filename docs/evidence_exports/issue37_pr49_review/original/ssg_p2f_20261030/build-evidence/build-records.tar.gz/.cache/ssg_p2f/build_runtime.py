#!/usr/bin/env python3
"""Rebuild the matched XOS threading SDK and Qt profile with recorded inputs."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

cache = Path(__file__).resolve().parent
root = cache.parents[1]
logs = cache / 'logs'
prefix = cache / 'prefix'
environment = os.environ.copy()
environment['PATH'] = str(prefix / 'bin') + ':' + environment['PATH']
environment['NASM'] = str(prefix / 'bin/nasm')
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
record = {'source_commit': source_commit, 'commands': [], 'status': 'RUNNING'}

def run(label, command):
    row = {'label': label, 'command': [str(x) for x in command],
           'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    record['commands'].append(row)
    print('START', label, flush=True)
    with (logs / (label + '.log')).open('w') as log:
        result = subprocess.run(row['command'], cwd=root, env=environment,
                                stdout=log, stderr=subprocess.STDOUT)
    row['returncode'] = result.returncode
    row['ended_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    (logs / 'runtime-build.json').write_text(json.dumps(record, indent=2) + '\n')
    print('DONE', label, result.returncode, flush=True)
    if result.returncode:
        record['status'] = 'FAILED'
        (logs / 'runtime-build.json').write_text(json.dumps(record, indent=2) + '\n')
        print((logs / (label + '.log')).read_text()[-6000:], flush=True)
        raise SystemExit(result.returncode)

run('threading-newlib', [sys.executable, root / 'scripts/build_threading_newlib.py',
    '--archive', cache / 'downloads/newlib-4.6.0.20260123.tar.gz',
    '--output', cache / 'threading_newlib', '--jobs', '4'])
sdk = root / 'build/ssg_p2f/sdk'
run('threading-sdk', [sys.executable, root / 'scripts/build_threading_sdk.py',
    '--newlib-prefix', cache / 'threading_newlib/prefix',
    '--gcc-source', cache / 'sources/gcc-16.2.0', '--cpp', '--jobs', '4', '--output', sdk])
qt = root / 'build/ssg_p2f/qt-widgets'
run('qt-target-configure', [sys.executable, root / 'src/ports/qt6/configure_widgets.py',
    '--source', cache / 'qt-target-source', '--build', qt, '--sdk', sdk,
    '--binutils', cache / 'target-tools', '--host-qt', cache / 'host-qt-official'])
run('qt-target-build', ['cmake', '--build', qt, '--target', 'Widgets', '--parallel', '4'])
record['status'] = 'BUILT'
record['sdk_manifest_sha256'] = hashlib.sha256((sdk / 'manifest.json').read_bytes()).hexdigest()
record['qt_cache_sha256'] = hashlib.sha256((qt / 'CMakeCache.txt').read_bytes()).hexdigest()
record['qt_archives'] = {str(p.relative_to(qt)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (qt / 'lib').glob('*.a')}
(logs / 'runtime-build.json').write_text(json.dumps(record, indent=2) + '\n')
print('MATCHED RUNTIME BUILT', flush=True)
