# Task-specific paths for this exact local bootstrap.
export XOS_P2F_ROOT=${XOS_ROOT}
export XOS_P2F_CACHE=${XOS_ROOT}/.cache/ssg_p2f
export XOS_P2F_PREFIX=${XOS_ROOT}/.cache/ssg_p2f/prefix
export XOS_P2F_HOST_QT=${XOS_ROOT}/.cache/ssg_p2f/host-qt-official
export XOS_P2F_QT_SOURCE=${XOS_ROOT}/.cache/ssg_p2f/qt-target-source
export XOS_P2F_QT_BUILD=${XOS_ROOT}/build/ssg_p2f/qt-widgets
export XOS_P2F_SDK=${XOS_ROOT}/build/ssg_p2f/sdk
export XOS_P2F_GCC_SOURCE=${XOS_ROOT}/.cache/ssg_p2f/sources/gcc-16.2.0
export XOS_P2F_NEWLIB_PREFIX=${XOS_ROOT}/.cache/ssg_p2f/threading_newlib/prefix
export XOS_P2F_BINUTILS=${XOS_ROOT}/.cache/ssg_p2f/target-tools
export NASM=${XOS_ROOT}/.cache/ssg_p2f/prefix/bin/nasm
export QEMU=${XOS_ROOT}/.cache/ssg_p2f/qemu-prefix/bin/qemu-system-x86_64
export PATH=${XOS_ROOT}/.cache/ssg_p2f/prefix/bin:"$PATH"
