# Task-specific paths for this exact local bootstrap.
export XOS_P2F_ROOT=/workspace/scratch/77fc8ad4822d/XylophoneOS
export XOS_P2F_CACHE=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f
export XOS_P2F_PREFIX=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/prefix
export XOS_P2F_HOST_QT=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/host-qt-official
export XOS_P2F_QT_SOURCE=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/qt-target-source
export XOS_P2F_QT_BUILD=/workspace/scratch/77fc8ad4822d/XylophoneOS/build/ssg_p2f/qt-widgets
export XOS_P2F_SDK=/workspace/scratch/77fc8ad4822d/XylophoneOS/build/ssg_p2f/sdk
export XOS_P2F_GCC_SOURCE=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/sources/gcc-16.2.0
export XOS_P2F_NEWLIB_PREFIX=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/threading_newlib/prefix
export XOS_P2F_BINUTILS=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/target-tools
export NASM=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/prefix/bin/nasm
export QEMU=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/qemu-prefix/bin/qemu-system-x86_64
export PATH=/workspace/scratch/77fc8ad4822d/XylophoneOS/.cache/ssg_p2f/prefix/bin:"$PATH"
